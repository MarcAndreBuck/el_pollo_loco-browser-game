class StartScreen {
    /**
     * @param {World} world
     * @param {HTMLCanvasElement} canvas
     * @param {ScreenManager} screenManager
     */
    constructor(world, canvas, screenManager) {
        this.world = world;
        this.canvas = canvas;
        this.screenManager = screenManager;

        this.isActive = true;

        this.background = new Image();
        // TODO: Pfad an dein Startscreen-Bild anpassen:
        this.background.src = "assets/9_intro_outro_screens/start/startscreen_1.png";

        this.buttons = this.createButtons();

        this.bindEvents();
        this.world.blocked = true; // solange Startscreen aktiv ist
    }

    createButtons() {
        return [
            ...this.createTopButtons(),
            ...this.createBottomButtons(),
        ];
    }

    /**
     * Obere Buttons: Steuerung & Story
     */
    createTopButtons() {
        const w = 0.20;   // 26% der Breite
        const h = 0.11;   // 11% der Höhe

        const y = 0.15;   // etwas über dem "EL POLLO LOCO"-Titel
        const gap = 0.04; // Abstand zwischen den Buttons

        const buttonConfigs = [
            { label: "Steuerung", action: () => this.openControls(), style: "wood" },
            { label: "Story", action: () => this.openStory(), style: "wood" },
        ];

        const buttonCount = buttonConfigs.length;
        const totalWidth = buttonCount * w + (buttonCount - 1) * gap;
        const startX = 0.5 - totalWidth / 2;

        return buttonConfigs.map((cfg, index) => {
            const x = startX + index * (w + gap);

            return new CanvasButton(
                x,
                y,
                w,
                h,
                cfg.label,
                state => {
                    if (!this.isActive || !state) return;
                    cfg.action();
                },
                cfg.style
            );
        });
    }

    /**
     * Untere Buttons: Impressum – Start (grün) – Settings
     */
    createBottomButtons() {
        const w = 0.26;
        const h = 0.11;

        const y = 0.86;   // knapp über dem unteren Rand
        const gap = 0.04;

        const buttonConfigs = [
            { label: "Datenschutz", action: () => this.openDataProtection(), style: "wood" },
            { label: "▶ Start", action: () => this.startGame(), style: "green" },
            { label: "Impressum", action: () => this.openImpressum(), style: "wood" },
        ];

        const buttonCount = buttonConfigs.length;
        const totalWidth = buttonCount * w + (buttonCount - 1) * gap;
        const startX = 0.5 - totalWidth / 2;

        return buttonConfigs.map((cfg, index) => {
            const x = startX + index * (w + gap);

            return new CanvasButton(
                x,
                y,
                w,
                h,
                cfg.label,
                state => {
                    if (!this.isActive || !state) return;
                    cfg.action();
                },
                cfg.style
            );
        });
    }

    bindEvents() {
        this.canvas.addEventListener("mousedown", e => {
            if (!this.isActive) return;
            const { x, y } = this.screenManager.getCanvasCoords(e);
            this.updatePressedState(x, y, true);
        });

        this.canvas.addEventListener("mouseup", () => {
            if (!this.isActive) return;
            this.resetButtons();
        });

        this.canvas.addEventListener("mousemove", e => {
            if (!this.isActive) return;
            const { x, y } = this.screenManager.getCanvasCoords(e);
            this.updateHoverState(x, y);
        });

        this.canvas.addEventListener("touchstart", e => {
            if (!this.isActive) return;
            e.preventDefault();
            const { x, y } = this.screenManager.getCanvasCoords(e);
            this.updatePressedState(x, y, true);
        }, { passive: false });

        this.canvas.addEventListener("touchend", e => {
            if (!this.isActive) return;
            e.preventDefault();
            this.resetButtons();
        }, { passive: false });
    }

    updatePressedState(x, y, isDown) {
        this.buttons.forEach(btn => {
            const inside = btn.contains(this.canvas, x, y);
            const pressedNow = isDown && inside;

            if (btn.pressed !== pressedNow) {
                btn.pressed = pressedNow;
                btn.onChange(btn.pressed);
            }
        });
    }

    updateHoverState(x, y) {
        this.buttons.forEach(btn => {
            const inside = btn.contains(this.canvas, x, y);
            btn.setHover(inside);
        });
    }

    resetButtons() {
        this.buttons.forEach(btn => {
            if (btn.pressed) {
                btn.onChange(false);
            }
            btn.pressed = false;
        });
    }

    /** Wird von World.draw() aufgerufen solange isActive == true */
    draw(ctx) {
        if (!this.isActive) return;

        // Hintergrundbild über das gesamte Canvas ziehen
        ctx.drawImage(this.background, 0, 0, this.canvas.width, this.canvas.height);

        // Buttons zeichnen
        this.buttons.forEach(btn => btn.draw(ctx, this.canvas));
    }

    /* ---------- Button Actions ---------- */

    startGame() {
        this.isActive = false;
        this.world.blocked = false;
    }

    toggleFullscreen() {
        if (this.screenManager.isFullscreen) {
            this.screenManager.exitFullscreen();
        } else {
            this.screenManager.enterFullscreen();
        }
    }


    openControls() {
        console.log("Steuerung anzeigen (kommt später als Overlay).");
    }

    openStory() {
        console.log("Story anzeigen (kommt später als Overlay).");
    }

    openDataProtection() {
        // TODO: Settings-Screen / Overlay später
        console.log("Settings öffnen (kommt später)...");
    }

    openImpressum() {
        // TODO: Impressum-Screen / Overlay später
        console.log("Impressum öffnen (kommt später)...");
    }
}
